<template>
  <div class="unify">
    <CommonHead />
    <div class="container-fluid">
      <img src="../../images/unify.png"
           alt=""
           class="img-responsive">
      <div class="col-lg-">
        <div class="row">
          <div class="col-lg-0 col-lg-4 col-md-4 col-sm-6 col-xs-10">
            <h4>响应习主席"厕所革命"的号召<br/>为实施乡村振兴战略贡献力量</h4>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-13 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <p>积极参与农村人居环境整治三年行动方案，为实施乡村振兴战略贡献力量</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import CommonHead from '@/components/head'
import CommonFoot from '@/components/foot'
import Swiper from '@/components/swiper'
export default {
  name: 'unify',
  data () {
    return {

    }
  },
  components: {
    CommonHead,
    CommonFoot,
    Swiper
  }
}
</script>

<style lang="scss" scoped>
.list-group-item {
  display: inline-block;
  flex: 1;
  padding: 0;
  font-size: 0 !important;
  border: none;
  img {
    width: 100%;
    height: 100%;
  }
}
.list-group {
  display: flex;
  margin-bottom: 0;
}
.navbar {
  margin-bottom: 0;
}
.container-fluid {
  padding: 0;
  margin: 0;
  position: relative;
}
.col-lg- {
  width: 100%;
  position: absolute;
  top: 0;
}
.col-lg-0 h4 {
  color: #1aa8aa;
}
.col-lg-13 {
  margin-top: 20px;
}
.col-lg-13 p {
  color: #303030;
}
</style>