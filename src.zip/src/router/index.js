import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  mode: 'history',
  hashbang: false,
  routes: [{
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/views/home/home'),
    meta: '官网首页'
  },
  {
    path: '/unify',
    name: 'unify',
    component: () => import('@/views/product/product_unify'),
    meta: '产品中心'
  }
  ]
})
